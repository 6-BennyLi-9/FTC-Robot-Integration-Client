package org.firstinspires.ftc.teamcode.Hardwares.namespace;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.hardware.HardwareDevice;

public interface DeviceInterface extends HardwareDevice, BNO055IMU {}