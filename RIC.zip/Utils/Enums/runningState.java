package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum runningState {
	Autonomous,
	ManualDrive
}
