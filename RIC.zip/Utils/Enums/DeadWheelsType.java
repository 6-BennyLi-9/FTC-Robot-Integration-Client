package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum DeadWheelsType {
	BE_NOT_USING_DEAD_WHEELS,
	TwoDeadWheels,
	ThreeDeadWheels
}
