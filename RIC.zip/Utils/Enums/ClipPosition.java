package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum ClipPosition {
	Open,
	Close
}
