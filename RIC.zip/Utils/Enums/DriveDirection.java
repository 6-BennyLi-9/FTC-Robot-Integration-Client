package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum DriveDirection {
	back,
	forward,
	left,
	right,
	slant,
	turn
}
