package org.firstinspires.ftc.teamcode.Utils.Annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Documented
public @interface DrivingPrograms {
}
