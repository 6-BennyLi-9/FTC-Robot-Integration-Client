package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import org.firstinspires.ftc.teamcode.keymap.KeyMap;

public class DefaultKeyMapController extends KeyMapController{
	@Override
	public void KeyMapOverride(@NonNull KeyMap keyMap) {
		/**/
	}
}
