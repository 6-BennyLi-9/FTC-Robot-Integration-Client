package org.firstinspires.ftc.teamcode;

public class DefaultParamsController extends ParamsController{
	@Override
	public void PramsOverride() {
		/**/
	}
}
