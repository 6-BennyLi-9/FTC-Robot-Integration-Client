package org.firstinspires.ftc.teamcode.utils.enums;

public enum driveDirection {
	back,
	forward,
	left,
	right,
	slant,
	turn
}
