package org.firstinspires.ftc.teamcode.utils.enums;

public enum State {
	FollowSpline,
	StrafeToPoint,
	ManualDriving,
	FinalState,
	BrakeDown,
	WaitingAtPoint,
	IDLE
}
