package org.firstinspires.ftc.teamcode.utils.enums;

public enum AutonomousLocation {
	left,
	centre,
	right,
	failed
}
