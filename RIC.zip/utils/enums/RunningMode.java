package org.firstinspires.ftc.teamcode.utils.enums;

public enum RunningMode {
	Autonomous,
	ManualDrive,
	TestOrTune,
	Debug,
	Sample
}
