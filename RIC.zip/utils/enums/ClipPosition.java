package org.firstinspires.ftc.teamcode.utils.enums;

public enum ClipPosition {
	Open,
	Close
}
