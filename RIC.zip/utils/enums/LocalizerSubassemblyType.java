package org.firstinspires.ftc.teamcode.utils.enums;

public enum LocalizerSubassemblyType {
	SingleLocalizer,
	SubassemblyLocalizer
}
