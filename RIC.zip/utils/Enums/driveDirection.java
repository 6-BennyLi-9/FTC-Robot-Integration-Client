package org.firstinspires.ftc.teamcode.utils.Enums;

public enum driveDirection {
	back,
	forward,
	left,
	right,
	slant,
	turn
}
