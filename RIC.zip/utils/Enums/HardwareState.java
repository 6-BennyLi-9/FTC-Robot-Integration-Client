package org.firstinspires.ftc.teamcode.utils.Enums;

public enum HardwareState {
	Enabled,
	Disabled
}
