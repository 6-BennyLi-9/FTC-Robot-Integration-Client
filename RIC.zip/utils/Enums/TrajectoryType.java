package org.firstinspires.ftc.teamcode.utils.Enums;

public enum TrajectoryType {
	LinerStrafe,
	Spline,
	TurnOnly,
	LinerWithTurn,
	WithoutChangingPosition
}
