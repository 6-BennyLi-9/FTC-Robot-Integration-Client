package org.firstinspires.ftc.teamcode.utils.Enums;

public enum AutonomousLocation {
	left,
	centre,
	right,
	failed
}
