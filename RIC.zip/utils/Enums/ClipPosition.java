package org.firstinspires.ftc.teamcode.utils.Enums;

public enum ClipPosition {
	Open,
	Close
}
