package org.firstinspires.ftc.teamcode.utils;

public final class Functions {
    public static double getCurrentTimeMills(){
        return System.nanoTime()/ 1.0E06;
    }
}
