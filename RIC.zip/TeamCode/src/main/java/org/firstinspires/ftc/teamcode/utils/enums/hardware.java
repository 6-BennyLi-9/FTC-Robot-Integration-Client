package org.firstinspires.ftc.teamcode.utils.enums;

public enum hardware {
	LeftFront,RightFront,LeftRear,RightRear,
	PlacementArm,
	Intake, FrontClip, RearClip, imu, SuspensionArm
}
