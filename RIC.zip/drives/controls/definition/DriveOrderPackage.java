package org.firstinspires.ftc.teamcode.drives.controls.definition;

import java.util.LinkedList;

public interface DriveOrderPackage {
	LinkedList<DriveOrder> getOrder();
}
