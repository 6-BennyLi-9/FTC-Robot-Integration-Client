package org.firstinspires.ftc.teamcode.drives.controls;

public enum TrajectoryType {
	LinerStrafe,
	Spline,
	TurnOnly,
	LinerWithTurn,
	WithoutChangingPosition
}
