package org.firstinspires.ftc.teamcode.drives.localizers.definition;

public interface LocalizerPlugin extends Localizer{}
