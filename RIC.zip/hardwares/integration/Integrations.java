package org.firstinspires.ftc.teamcode.hardwares.integration;

import org.firstinspires.ftc.teamcode.utils.Timer;

public interface Integrations {
	void update();
	Timer timer=new Timer();
}
