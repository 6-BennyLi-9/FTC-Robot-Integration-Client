package org.firstinspires.ftc.teamcode.hardwares.integration.gamepads;

public enum KeyButtonType {
	A,
	B,
	X,
	Y,

	DpadUp,
	DpadDown,
	DpadLeft,
	DpadRight
}
