package org.firstinspires.ftc.teamcode.hardwares.integration.gamepads;

public enum KeyMapSettingType {
	RunWhenButtonPressed,
	RunWhenButtonPressingBooleanChanged,
	RunWhenButtonHold,
	SinglePressToChangeRunAble,
	PullRod
}
