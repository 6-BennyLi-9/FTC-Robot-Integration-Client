package org.firstinspires.ftc.teamcode.hardwares.integration.gamepads;

public enum KeyRodType {
	LeftStickX,
	LeftStickY,
	RightStickX,
	RightStickY
}
