package org.firstinspires.ftc.teamcode.hardwares;

public enum LiftPosition {
	IDLE,
	Low,
	High
}
