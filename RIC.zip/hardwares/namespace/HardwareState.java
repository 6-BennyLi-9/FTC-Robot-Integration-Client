package org.firstinspires.ftc.teamcode.hardwares.namespace;

public enum HardwareState {
	Enabled,
	Disabled
}
