package org.firstinspires.ftc.teamcode.hardwares.basic;

public enum ClipPosition {
	Open,
	Close
}
