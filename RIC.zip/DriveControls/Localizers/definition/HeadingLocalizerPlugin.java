package org.firstinspires.ftc.teamcode.DriveControls.Localizers.definition;

public interface HeadingLocalizerPlugin extends LocalizerPlugin{
	double getHeadingDeg();
}
