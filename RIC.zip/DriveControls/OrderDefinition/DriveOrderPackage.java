package org.firstinspires.ftc.teamcode.DriveControls.OrderDefinition;

import java.util.LinkedList;

public interface DriveOrderPackage {
	LinkedList<DriveOrder> getOrder();
}
