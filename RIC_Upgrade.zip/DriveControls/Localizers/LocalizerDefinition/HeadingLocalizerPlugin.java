package org.firstinspires.ftc.teamcode.DriveControls.Localizers.LocalizerDefinition;

public interface HeadingLocalizerPlugin extends LocalizerPlugin{
	double getHeadingDeg();
}
