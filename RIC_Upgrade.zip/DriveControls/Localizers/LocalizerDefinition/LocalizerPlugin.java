package org.firstinspires.ftc.teamcode.DriveControls.Localizers.LocalizerDefinition;

public interface LocalizerPlugin extends Localizer{}
