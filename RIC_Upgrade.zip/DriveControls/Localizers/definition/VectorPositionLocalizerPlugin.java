package org.firstinspires.ftc.teamcode.DriveControls.Localizers.definition;

import com.acmerobotics.roadrunner.Vector2d;

public interface VectorPositionLocalizerPlugin extends LocalizerPlugin{
	Vector2d getCurrentVector();
}
