package org.firstinspires.ftc.teamcode.DriveControls.Localizers.definition;

public interface LocalizerPlugin extends Localizer{}
