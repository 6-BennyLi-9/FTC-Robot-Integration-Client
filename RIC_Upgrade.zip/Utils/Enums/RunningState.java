package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum RunningState {
	Autonomous,
	ManualDrive
}
