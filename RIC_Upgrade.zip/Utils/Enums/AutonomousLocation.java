package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum AutonomousLocation {
	left,
	centre,
	right,
	failed
}
