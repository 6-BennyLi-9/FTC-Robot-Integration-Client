package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum TrajectoryType {
	LinerStrafe,
	Spline,
	TurnOnly,
	LinerWithTurn,
	WithoutChangingPosition
}
