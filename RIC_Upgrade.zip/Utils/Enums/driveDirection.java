package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum driveDirection {
	back,
	forward,
	left,
	right,
	slant,
	turn
}
