package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum State {
	FollowSpline,
	StrafeToPoint,
	ManualDriving,
	FinalState,
	BrakeDown,
	WaitingAtPoint,
	IDLE
}
