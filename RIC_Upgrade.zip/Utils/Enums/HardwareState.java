package org.firstinspires.ftc.teamcode.Utils.Enums;

public enum HardwareState {
	Enabled,
	Disabled
}
