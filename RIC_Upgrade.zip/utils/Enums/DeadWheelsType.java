package org.firstinspires.ftc.teamcode.utils.Enums;

public enum DeadWheelsType {
	BE_NOT_USING_DEAD_WHEELS,
	TwoDeadWheels,
	ThreeDeadWheels
}
