package org.firstinspires.ftc.teamcode.utils.Enums;

public enum runningState {
	Autonomous,
	ManualDrive
}
