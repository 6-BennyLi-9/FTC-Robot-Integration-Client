package org.firstinspires.ftc.teamcode.utils.Enums;

public enum State {
	FollowSpline,
	StrafeToPoint,
	ManualDriving,
	FinalState,
	BrakeDown,
	WaitingAtPoint,
	IDLE
}
