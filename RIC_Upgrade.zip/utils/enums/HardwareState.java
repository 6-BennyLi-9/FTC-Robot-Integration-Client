package org.firstinspires.ftc.teamcode.utils.enums;

public enum HardwareState {
	Enabled,
	Disabled
}
