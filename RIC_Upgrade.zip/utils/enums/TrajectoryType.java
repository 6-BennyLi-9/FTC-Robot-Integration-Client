package org.firstinspires.ftc.teamcode.utils.enums;

public enum TrajectoryType {
	LinerStrafe,
	Spline,
	TurnOnly,
	LinerWithTurn,
	WithoutChangingPosition
}
